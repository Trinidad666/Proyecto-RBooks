<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RBooks</title>
    <link rel="stylesheet" type="text/css" href="css/libros-style.css" />
    <link rel="stylesheet" type="text/css" href="css/header.css" />
    <link rel="stylesheet" type="text/css" href="css/footer.css" />
    <link rel="icon" type="image/x-icon" href="rsc/logo.png">
    <style>
        .title {
            font-family: "Raleway";
            font-size: 24px;
            font-weight: 700;
            color: #5D4037;
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <header>
        <a href="index.php" class="logo">
            <img src="rsc/logo.png" alt="Logo">
            <h2>ooks</h2>
        </a>
        <nav>
            <ul>
                <li><a href="libros.php" class="nav-link">Libros</a>
                    <ul>
                        <li><a href="#">Ficción</a></li>
                        <li><a href="#">No Ficción</a></li>
                        <li><a href="#">Biografías</a></li>
                        <li><a href="#">Ciencia Ficción</a></li>
                    </ul>
                </li>
                <li><a href="comics.php" class="nav-link">Comics</a>
                    <ul>
                        <li><a href="#">Superhéroes</a></li>
                        <li><a href="#">Manga</a></li>
                        <li><a href="#">Historietas</a></li>
                    </ul>
                </li>
                <li><a href="audio_libros.php" class="nav-link">Audio Libros</a>
                    <ul>
                        <li><a href="#">Narrativa</a></li>
                        <li><a href="#">Educativos</a></li>
                        <li><a href="#">Entretenimiento</a></li>
                    </ul>
                </li>
                <li><a href="estanteria.php" class="nav-link">Estanterias</a></li>
                <li><a href="biblioteca.php" class="nav-link">Mi Biblioteca</a></li>
                <li><a href="in-sign.php" class="botton-iniciar">Sign In</a></li>
                <li><a href="php_in-sing/cerrar_sesion.php" class="botton-iniciar">Cerra Sesion</a></li>

            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <div id="carouselExampleIndicators" class="carousel">
        
        <div class="hero-text">
            <h1 class="mb-4">Libros</h1>
        </div>
    </div>

    <!-- //////////////////////////////////////////// -->
    <!-- LibrosS -->
    <!-- //////////////////////////////////////////// -->
    <!-- Hover over the cards
    <h1 class="title">Libros</h1> -->
    <div id="app" class="container">
        <!-- Tarjeta 1 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/el señor de los anillos.jpg" alt="Canyons" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>El señor de los anillos</h1>
                        <p>El Señor de los Anillos es una épica historia de fantasía en la que un grupo diverso lucha por destruir un anillo maligno que amenaza con sumir al mundo en oscuridad.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 2 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/los señores de la guerra.jpg" alt="Beaches" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Los señores de la guerra</h1>
                        <p>Los Señores de la Guerra suelen referirse a líderes militares o figuras poderosas que controlan regiones mediante la fuerza, a menudo actuando fuera de un sistema estatal centralizado.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 3 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/Don Quijote y Sancho.jpg" alt="Trees" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Don Quijote y Sancho</h1>
                        <p>Don Quijote y Sancho Panza son los icónicos protagonistas de Don Quijote de la Mancha de Cervantes: un idealista caballero que busca revivir la caballería y su pragmático escudero, formando un dúo que combina locura, humor y profundas reflexiones sobre la vida.</p>
                        <!-- Don Quijote y Sancho Panza son un caballero idealista y su escudero realista que juntos exploran la locura, la aventura y la humanidad. -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Tarjeta 4 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/el señor de los anillos.jpg" alt="Canyons" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>El señor de los anillos</h1>
                        <p>El Señor de los Anillos es una épica historia de fantasía en la que un grupo diverso lucha por destruir un anillo maligno que amenaza con sumir al mundo en oscuridad.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 5 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/los señores de la guerra.jpg" alt="Beaches" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Los señores de la guerra</h1>
                        <p>Los Señores de la Guerra suelen referirse a líderes militares o figuras poderosas que controlan regiones mediante la fuerza, a menudo actuando fuera de un sistema estatal centralizado.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 6 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/Don Quijote y Sancho.jpg" alt="Trees" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Don Quijote y Sancho</h1>
                        <p>Don Quijote y Sancho Panza son los icónicos protagonistas de Don Quijote de la Mancha de Cervantes: un idealista caballero que busca revivir la caballería y su pragmático escudero, formando un dúo que combina locura, humor y profundas reflexiones sobre la vida.</p>
                        <!-- Don Quijote y Sancho Panza son un caballero idealista y su escudero realista que juntos exploran la locura, la aventura y la humanidad. -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Tarjeta 7 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/el señor de los anillos.jpg" alt="Canyons" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>El señor de los anillos</h1>
                        <p>El Señor de los Anillos es una épica historia de fantasía en la que un grupo diverso lucha por destruir un anillo maligno que amenaza con sumir al mundo en oscuridad.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 8 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/los señores de la guerra.jpg" alt="Beaches" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Los señores de la guerra</h1>
                        <p>Los Señores de la Guerra suelen referirse a líderes militares o figuras poderosas que controlan regiones mediante la fuerza, a menudo actuando fuera de un sistema estatal centralizado.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 9 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/Don Quijote y Sancho.jpg" alt="Trees" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Don Quijote y Sancho</h1>
                        <p>Don Quijote y Sancho Panza son los icónicos protagonistas de Don Quijote de la Mancha de Cervantes: un idealista caballero que busca revivir la caballería y su pragmático escudero, formando un dúo que combina locura, humor y profundas reflexiones sobre la vida.</p>
                        <!-- Don Quijote y Sancho Panza son un caballero idealista y su escudero realista que juntos exploran la locura, la aventura y la humanidad. -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Tarjeta 10 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/el señor de los anillos.jpg" alt="Canyons" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>El señor de los anillos</h1>
                        <p>El Señor de los Anillos es una épica historia de fantasía en la que un grupo diverso lucha por destruir un anillo maligno que amenaza con sumir al mundo en oscuridad.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 11 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/los señores de la guerra.jpg" alt="Beaches" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Los señores de la guerra</h1>
                        <p>Los Señores de la Guerra suelen referirse a líderes militares o figuras poderosas que controlan regiones mediante la fuerza, a menudo actuando fuera de un sistema estatal centralizado.</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Tarjeta 12 -->
        <div class="card-wrap">
            <div class="card">
                <div class="card-inner">
                    <div class="card-front">
                        <img src="rsc/index/Don Quijote y Sancho.jpg" alt="Trees" class="card-image">
                    </div>
                    <div class="card-back">
                        <h1>Don Quijote y Sancho</h1>
                        <p>Don Quijote y Sancho Panza son los icónicos protagonistas de Don Quijote de la Mancha de Cervantes: un idealista caballero que busca revivir la caballería y su pragmático escudero, formando un dúo que combina locura, humor y profundas reflexiones sobre la vida.</p>
                        <!-- Don Quijote y Sancho Panza son un caballero idealista y su escudero realista que juntos exploran la locura, la aventura y la humanidad. -->
                    </div>
                </div>
            </div>

            <?php 
                // if (mysqli_num_rows($result) > 0) {
                //     // Recorrer mastrap resultados 
                //     while ($row = mysqli_fetch_assoc($result)) {
                //         echo "<div class='md'>"
                //         " Nombre: " . $row["username"]."<br>" .
                //         " Email: " . $row["email"]."<br>" .
                //     "</div>";
                //     }
                // } else { 
                //     echo "No se encontraron resultados.";
                // }
            ?>
        </div>
        
        






    </div>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <!-- Logo -->
            <div class="logo">
                <img src="rsc/logo.png" alt="Logo">
            </div>
            <!-- Texto del footer -->
            <div class="footer-text">
                <p>Texto del Footer</p>
            </div>
            <!-- Logotipos -->
            <div class="logos">
                <img src="rsc/Youtube.png" alt="Logo 1">
                <img src="rsc/discord.png" alt="Logo 2">
                <img src="rsc/Instagram-removebg-preview.png" alt="Logo 3">
                <!-- <img src="rsc/Youtube.png" alt="Logo 4"> -->
            </div>
        </div>
    </footer>
</body>
</html>



<!-- para las imagenes:

https://cloudconvert.com/webp-to-jpg -->
