-- MySQL Script for rbooks schema

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION';

CREATE SCHEMA IF NOT EXISTS `rbooks` DEFAULT CHARACTER SET utf8 ;
USE `rbooks` ;

-- Table Cliente
CREATE TABLE IF NOT EXISTS `Cliente` (
  `idcliente` INT NOT NULL AUTO_INCREMENT,
  `usuario` VARCHAR(45) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idcliente`)
) ENGINE = InnoDB;


-- Table Producto
CREATE TABLE IF NOT EXISTS `Producto` (
  `idproducto` INT NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(45) NOT NULL,
  `generos` VARCHAR(45) NOT NULL,
  `precio` DECIMAL(10,2) NOT NULL,
  `portada` VARCHAR(45) NOT NULL,
  `sinopsis` VARCHAR(255) NOT NULL,
  `fecha_publicacion` DATETIME NOT NULL,
  `idautor` INT NOT NULL,
  `tipo` INT NOT NULL,
  PRIMARY KEY (`idproducto`))
ENGINE = InnoDB;

-- Table Producto_Cliente
CREATE TABLE IF NOT EXISTS `Producto_Cliente` (
  `idproducto` INT NOT NULL,
  `idcliente` INT NOT NULL,
  PRIMARY KEY (`idproducto`, `idcliente`),
  CONSTRAINT `fk_producto_cliente_cliente`
    FOREIGN KEY (`idcliente`)
    REFERENCES `Cliente` (`idcliente`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_producto_cliente_producto`
    FOREIGN KEY (`idproducto`)
    REFERENCES `Producto` (`idproducto`)
    ON DELETE CASCADE)
ENGINE = InnoDB;

-- Table Ventas
CREATE TABLE IF NOT EXISTS `Ventas` (
  `idventas` INT NOT NULL AUTO_INCREMENT,
  `fecha_hora` DATETIME NOT NULL,
  `dato` DECIMAL(10,2) NOT NULL,
  `precio` DECIMAL(10,2) NOT NULL,
  `precio_sin_IVA` DECIMAL(10,2) NOT NULL,
  `idcliente` INT NOT NULL,
  PRIMARY KEY (`idventas`),
  INDEX `idcliente_idx` (`idcliente`),
  CONSTRAINT `fk_ventas_cliente`
    FOREIGN KEY (`idcliente`)
    REFERENCES `Cliente` (`idcliente`)
    ON DELETE CASCADE)
ENGINE = InnoDB;

-- Table Ventas_Producto
CREATE TABLE IF NOT EXISTS `Ventas_Producto` (
  `idventas` INT NOT NULL,
  `idproducto` INT NOT NULL,
  PRIMARY KEY (`idventas`, `idproducto`),
  INDEX `idproducto_idx` (`idproducto`),
  CONSTRAINT `fk_ventas_producto_ventas`
    FOREIGN KEY (`idventas`)
    REFERENCES `Ventas` (`idventas`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_ventas_producto_producto`
    FOREIGN KEY (`idproducto`)
    REFERENCES `Producto` (`idproducto`)
    ON DELETE CASCADE)
ENGINE = InnoDB;

-- Table Pago
CREATE TABLE IF NOT EXISTS `Pago` (
  `idpago` INT NOT NULL AUTO_INCREMENT,
  `coste_total` DECIMAL(10,2) NOT NULL,
  `metodo_pago` VARCHAR(45) NOT NULL,
  `idventa` INT NOT NULL,
  PRIMARY KEY (`idpago`),
  INDEX `idventa_idx` (`idventa`),
  CONSTRAINT `fk_pago_ventas`
    FOREIGN KEY (`idventa`)
    REFERENCES `Ventas` (`idventas`)
    ON DELETE CASCADE)
ENGINE = InnoDB;

-- Table Garantia
CREATE TABLE IF NOT EXISTS `Garantia` (
  `idgarantia` INT NOT NULL AUTO_INCREMENT,
  `duracion` INT NOT NULL,
  `cobertura` VARCHAR(255) NOT NULL,
  PRIMARY KEY (`idgarantia`))
ENGINE = InnoDB;

-- Table Producto_Garantia
CREATE TABLE IF NOT EXISTS `Producto_Garantia` (
  `idproducto` INT NOT NULL,
  `idgarantia` INT NOT NULL,
  PRIMARY KEY (`idproducto`, `idgarantia`),
  INDEX `idgarantia_idx` (`idgarantia`),
  CONSTRAINT `fk_producto_garantia_producto`
    FOREIGN KEY (`idproducto`)
    REFERENCES `Producto` (`idproducto`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_producto_garantia_garantia`
    FOREIGN KEY (`idgarantia`)
    REFERENCES `Garantia` (`idgarantia`)
    ON DELETE CASCADE)
ENGINE = InnoDB;

-- Table Autor
CREATE TABLE IF NOT EXISTS `Autor` (
  `idautor` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `correo_electronico` VARCHAR(45) NOT NULL,
  `genero_literario` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idautor`))
ENGINE = InnoDB;

-- Table Editorial
CREATE TABLE IF NOT EXISTS `Editorial` (
  `ideditorial` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `direccion` VARCHAR(255) NOT NULL,
  `correo_electronico` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ideditorial`))
ENGINE = InnoDB;

-- Table Editorial_Producto
CREATE TABLE IF NOT EXISTS `Editorial_Producto` (
  `ideditorial` INT NOT NULL,
  `idproducto` INT NOT NULL,
  PRIMARY KEY (`ideditorial`, `idproducto`),
  INDEX `idproducto_idx` (`idproducto`),
  CONSTRAINT `fk_editorial_producto`
    FOREIGN KEY (`ideditorial`)
    REFERENCES `Editorial` (`ideditorial`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_producto_editorial`
    FOREIGN KEY (`idproducto`)
    REFERENCES `Producto` (`idproducto`)
    ON DELETE CASCADE)
ENGINE = InnoDB;

-- Table Mi_Biblioteca
CREATE TABLE IF NOT EXISTS `Mi_Biblioteca` (
  `idcliente` INT NOT NULL,
  `idproducto` INT NOT NULL,
  PRIMARY KEY (`idcliente`, `idproducto`),
  INDEX `idproducto_idx` (`idproducto`),
  CONSTRAINT `fk_mibiblioteca_cliente`
    FOREIGN KEY (`idcliente`)
    REFERENCES `Cliente` (`idcliente`)
    ON DELETE CASCADE,
  CONSTRAINT `fk_mibiblioteca_producto`
    FOREIGN KEY (`idproducto`)
    REFERENCES `Producto` (`idproducto`)
    ON DELETE CASCADE)
ENGINE = InnoDB;


-- Inserts para la tabla Cliente
INSERT INTO `Cliente` (`usuario`, `password`, `email`) VALUES
('jdoe', '123', 'jdoe@example.com'),
('asmith', 'my', 'asmith@example.com'),
('mjones', 'securepass', 'mjones@example.com');

-- Inserts para la tabla Autor
INSERT INTO `Autor` (`nombre`, `correo_electronico`, `genero_literario`) VALUES
('Gabriel García Márquez', 'gabo@literatura.com', 'Realismo Mágico'),
('Jane Austen', 'jane.austen@fiction.com', 'Romance'),
('J.K. Rowling', 'jk.rowling@magicworld.com', 'Fantasía');

-- Inserts para la tabla Producto
-- Libros 0
-- Comics 1
-- Audio Libros 2
INSERT INTO `Producto` (`titulo`, `generos`, `precio`, `portada`, `sinopsis`, `fecha_publicacion`, `idautor`, `tipo`) VALUES
-- Libros
('Canción Hielo Fuego', 'Fantasia', 25.00, 'rsc/libros/Canción-Hielo-Fuego.jpg', 'Luchas medievales por el Trono de Hierro, traiciones y magia amenazan el mundo del norte.', '1996-08-06', 1, 0),
('Don Quijote y Sancho', 'Novela clasica', 15.00, 'rsc/libros/don_quijote.jpg', 'Don Quijote y Sancho Panza viven aventuras, enfrentando locura, humor y profundas reflexiones sobre la vida.', '1605-01-16', 2, 0),
('El Resplandor', 'Terror', 20.00, 'rsc/libros/El-Resplandor.jpg', 'Un escritor cuida un hotel aislado, pero fuerzas sobrenaturales afectan a su familia.', '1977-01-28', 3, 0),
('El Retorno del Rey', 'Fantasia', 20.00, 'rsc/libros/El-Retorno-Del-Rey.jpg', 'Frodo lucha por destruir el Anillo Único mientras Aragorn reclama su lugar como rey.', '1955-10-20', 4, 0),
('Holly', 'Novela', 25.00, 'rsc/libros/Holly.jpg', 'Holly Gibney investiga la desaparición de una joven y descubre oscuros secretos familiares.', '2023-06-04', 5, 0),
('La reina del sur', 'Novela', 15.00, 'rsc/libros/La-reina-del-sur.jpg', 'Teresa Mendoza se convierte en reina de un imperio de drogas tras la muerte de su novio.', '2002-05-07', 6, 0),
('La Cúpula', 'Ciencia ficcion', 25.00, 'rsc/libros/La-Cúpula.jpg', 'Una cúpula invisible aísla un pueblo, desatando caos, luchas de poder y secretos oscuros.', '2009-11-10', 7, 0),
('La Niebla', 'Terror', 9.00, 'rsc/libros/La-Nievla.jpg', 'Una niebla mortal envuelve un pueblo, trayendo criaturas, y un grupo lucha por sobrevivir.', '1980-11-01', 8, 0),
('La Torre Oscura', 'Terror', 45.00, 'rsc/libros/La-Torre_Oscura.jpg', 'Roland Deschain lucha por alcanzar la Torre Oscura enfrentando criaturas y su destino fatal.', '1982-11-10', 9, 0),
('El señor de los anillos', 'Fantasia', 40.00, 'rsc/libros/lord-of-the-rings.jpg', 'Un grupo diverso lucha para destruir un anillo maligno que amenaza con sumir al mundo.', '1954-07-29', 10, 0),
('Los señores de la guerra', 'Historia', 20.00, 'rsc/libros/señores-de-la-guerra.jpg', 'El libro explora la figura de los mercenarios y los "señores de la guerra" a lo largo de la historia.', '2001-05-03', 11, 0),
('The Thing', 'Terror', 15.00, 'rsc/libros/The-Thing.jpg', 'Un grupo de investigadores se enfrenta a un alienígena que puede imitar a cualquier ser vivo.', '1982-06-25', 12, 0),

-- Comics
('One Piece', 'Shonen', 8.00, 'rsc/comic/one_piece.jpg', 'Monkey D. Luffy busca el tesoro "One Piece" para ser Rey de los Piratas.', '1997-07-22', 1, 1),
('Batman: Más Allá del Caballero Blanco', 'Superheroes', 15.00, 'rsc/comic/Batman-Caballero-Blanco.jpg', 'Terry McGinnis asume el manto de Batman mientras Gotham enfrenta nuevas amenazas.', '2019-01-01', 2, 1),
('Berserk', 'Terror', 12.00, 'rsc/comic/Berserk.jpg', 'Guts lucha contra demonios y humanos en un mundo medieval brutal, buscando venganza y propósito.', '1989-08-25', 3, 1),
('Marvel: Civil War', 'Superheroes', 22.00, 'rsc/comic/civil_war.jpg', 'Los héroes de Marvel se enfrentan por el registro de superhéroes, dividiéndose entre Iron Man y Capitán América.', '2006-03-01', 4, 1),
('The Darkness', 'Superheroes', 19.00, 'rsc/comic/Darkness.jpg', 'Jackie Estacado lucha contra enemigos sobrenaturales mientras equilibra su vida como mafioso.', '1996-12-01', 5, 1),
('Hellboy: Enamorado', 'Fantasia', 14.00, 'rsc/comic/Hellboy.jpeg', 'Hellboy enfrenta fuerzas sobrenaturales mientras lidia con su naturaleza demoníaca y su relación con una mujer.', '2004-02-11', 6, 1),
('Pestilence', 'Terror', 15.00, 'rsc/comic/Pestilencia.jpg', 'Caballeros medievales luchan contra la peste sobrenatural arrasando Europa durante la Edad Media.', '2017-03-01', 7, 1),
('Batman: El Regreso del Caballero Oscuro', 'Superheroes', 30.00, 'rsc/comic/regreso_caballero_oscuro.jpg', 'Bruce Wayne regresa como Batman para salvar Gotham de nuevas amenazas mientras enfrenta sus demonios.', '1986-02-01', 8, 1),
('Sin City', 'Noir', 10.00, 'rsc/comic/sin_city.jpg', 'Marv lucha por venganza en una ciudad corrupta y violenta enfrentando crimen y brutalidad.', '1991-04-01', 9, 1),
('Solo Leveling', 'Accion', 15.00, 'rsc/comic/Solo_Leveling.jpg', 'Jinwoo sube de nivel y se convierte en el cazador más poderoso mientras enfrenta misterios sobrenaturales.', '2018-03-04', 10, 1),
('Spawn', 'Superheroes', 15.00, 'rsc/comic/Spawn.jpg', 'Al Simmons regresa como Spawn para luchar contra demonios y su propio destino infernal.', '1992-08-01', 11, 1),
('Lobezno: El Viejo Logan', 'Superheroes', 15.00, 'rsc/comic/viejo-logan.jpg', 'Lobezno vive retirado pero regresa para enfrentar nuevas amenazas en una América post-apocalíptica.', '2008-11-01', 12, 1),

-- Audio Librios
('A Mala Sangre', 'Misterio', 12.00, 'rsc/audio/A-Mala-Sangre.jpg', 'Un detective y periodista investigan crímenes relacionados con una familia poderosa y oscuros secretos.', '2012-03-05', 1, 2),
('Al Sur del Mundo', 'Aventura', 20.00, 'rsc/audio/Al-Sur-del-Mundo.jpg', 'Un explorador viaja a las regiones más remotas enfrentando desafíos extremos por supervivencia.', '2015-07-08', 2, 2),
('Amor Salvaje', 'Romance', 15.00, 'rsc/audio/Amor-Salvaje.jpg', 'Una historia de amor apasionada enfrenta miedos y luchas por un amor auténtico y salvaje.', '2019-04-15', 3, 2),
('Diario de Supervivencia Zombie', 'Apocalíptico', 15.00, 'rsc/audio/Diario-de-Supervivencia-Zombi.jpg', 'Un hombre documenta su lucha por sobrevivir en un mundo post-apocalíptico lleno de zombis.', '2011-11-22', 4, 2),
('El Gato Negro', 'Misterio', 15.00, 'rsc/audio/El-Gato-Negro.jpg', 'Un hombre narra cómo su vida se desmorona tras adoptar un gato negro y violencia.', '1843-03-01', 5, 2),
('El Regalo', 'Misterio', 5.00, 'rsc/audio/El-Regalo.jpg', 'Un hombre recibe un regalo misterioso que cambia su vida y pone a prueba su moralidad.', '2020-09-01', 6, 2),
('El Reloj de Bolsillo', 'Suspenso', 9.00, 'rsc/audio/El-Reloj-de-Bolsillo.jpg', 'Un antiguo reloj conecta al protagonista con momentos del pasado, desvelando secretos oscuros.', '1998-02-13', 7, 2),
('Entre Selva y Hielo', 'Aventura', 20.00, 'rsc/audio/Entre-la-Selva-y-el-Hielo.jpg', 'La obra narra la experiencia de un grupo de exploradores que enfrentan los desafíos extremos de la selva y el hielo, luchando por sobrevivir en condiciones implacables mientras buscan descubrir lo desconocido.', '2017-10-06', 8, 2),
('La Divina Comedia', 'Poesia', 15.00, 'rsc/audio/La-Divina-Comedia.jpg', 'La obra maestra de Dante Alighieri relata el viaje del poeta a través del Infierno, el Purgatorio y el Paraíso, guiado por Virgilio y Beatriz, en una alegoría sobre el alma humana y su destino eterno.', '1320-01-01', 9, 2),
('La Visión', 'Suspenso', 15.00, 'rsc/audio/La-Visión.jpg', 'La historia sigue a un protagonista que experimenta una serie de visiones misteriosas que lo llevan a descubrir secretos ocultos, enfrentando dilemas morales mientras busca respuestas.', '2019-05-15', 10, 2),
('Oscuridad', 'Horror', 15.00, 'rsc/audio/Oscuridad.jpg', 'Un hombre se enfrenta a sus peores miedos cuando una serie de extraños eventos lo sumergen en un mundo de oscuridad literal y metafórica, desafiando su comprensión de la realidad y su propia cordura.', '2018-08-13', 11, 2),
('Terror de Terrores', 'Horror', 15.00, 'rsc/audio/Terror-De-Terrores.jpg', 'Una colección de relatos escalofriantes que exploran los miedos más profundos y lo sobrenatural, llevando al lector a enfrentarse a horrores indescriptibles y situaciones extremas de terror psicológico.', '2015-10-22', 12, 2);



-- ALTER TABLE `Producto` MODIFY `sinopsis` TEXT;





-- Inserts para la tabla Editorial
INSERT INTO `Editorial` (`nombre`, `direccion`, `correo_electronico`) VALUES
('Editorial Planeta', 'Calle Literatura 123, Ciudad de México', 'contacto@planeta.com'),
('Penguin Random House', '123 Main Street, New York', 'info@penguinrandomhouse.com'),
('Bloomsbury Publishing', '50 Bedford Square, London', 'info@bloomsbury.com');

-- Inserts para la tabla Editorial_Producto
INSERT INTO `Editorial_Producto` (`ideditorial`, `idproducto`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- Inserts para la tabla Ventas
INSERT INTO `Ventas` (`fecha_hora`, `dato`, `precio`, `precio_sin_IVA`, `idcliente`) VALUES
('2024-11-20 15:30:00', 19.99, 19.99, 16.52, 1),
('2024-11-20 16:00:00', 14.50, 14.50, 12.02, 2),
('2024-11-20 16:30:00', 25.00, 25.00, 20.66, 3);

-- Inserts para la tabla Ventas_Producto
INSERT INTO `Ventas_Producto` (`idventas`, `idproducto`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- Inserts para la tabla Pago
INSERT INTO `Pago` (`coste_total`, `metodo_pago`, `idventa`) VALUES
(19.99, 'Tarjeta de Crédito', 1),
(14.50, 'Paypal', 2),
(25.00, 'Transferencia Bancaria', 3);

-- Inserts para la tabla Garantia
INSERT INTO `Garantia` (`duracion`, `cobertura`) VALUES
(12, 'Cubre daños físicos y defectos de fábrica'),
(24, 'Cubre reparaciones y reemplazo'),
(36, 'Garantía extendida sin preguntas');

-- Inserts para la tabla Producto_Garantia
INSERT INTO `Producto_Garantia` (`idproducto`, `idgarantia`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- Inserts para la tabla Mi_Biblioteca
INSERT INTO `Mi_Biblioteca` (`idcliente`, `idproducto`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- Inserts para la tabla Producto_Cliente
INSERT INTO `Producto_Cliente` (`idproducto`, `idcliente`) VALUES
(1, 1),
(2, 2),
(3, 3);






SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
