<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RBooks</title>
    <link rel="stylesheet" type="text/css" href="css/estanteria-style.css" />
    <link rel="stylesheet" type="text/css" href="css/header.css" />
    <link rel="stylesheet" type="text/css" href="css/footer.css" />
    <link rel="icon" type="image/x-icon" href="rsc/logo.png">
    <style>
        /* Barra lateral */
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 120px;
            left: -250px; /* Comienza fuera de la pantalla */
            background-color: #FF5722;
            overflow-x: hidden;
            transition: 0.3s; /* Transición suave */
            padding-top: 60px;
            z-index: 1000; /* Asegura que la barra lateral esté por encima de otros elementos */
        }
        .sidebar a {
            padding: 8px 8px 8px 32px;
            text-decoration: none;
            font-size: 25px;
            color: white;
            display: block;
            transition: 0.3s;
        }
        .sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Estilo del botón con las tres barras horizontales */
        .open-btn {
            font-size: 30px;
            color: white;
            background-color: #FF5722;
            padding: 15px;
            cursor: pointer;
            border: none;
            position: fixed;
            top: 120px;
            left: 20px;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1001; /* Asegura que el botón esté por encima de la barra lateral */
        }
        .open-btn:hover {
            background-color: #FF5722;
        }

        /* Estilo para las tres barras dentro del botón */
        .open-btn span {
            display: block;
            width: 30px;
            height: 5px;
            background-color: white;
            margin: 6px 0;
            border-radius: 2px;
        }

        /* Asegura que el contenido debajo de la barra lateral sea accesible */
        .content {
            margin-left: 0;
            transition: margin-left 0.3s;
        }

        .sidebar.open + .content {
            margin-left: 250px; /* Cuando la barra lateral está abierta */
        }
    </style>
</head>
<body>
    <!-- Barra lateral -->
    <div id="mySidebar" class="sidebar">
        <a href="javascript:void(0)" class="closebtn" onclick="toggleSidebar()">×</a>
        <a href="#" onclick="mostrarProductosPorGenero('Fantasía')">Fantasía</a>
        <a href="#" onclick="mostrarProductosPorGenero('Novela Clásica')">Novela Clásica</a>
        <a href="#" onclick="mostrarProductosPorGenero('Terror')">Terror</a>
        <a href="#" onclick="mostrarProductosPorGenero('Ciencia Ficción')">Ciencia Ficción</a>
        <a href="#" onclick="mostrarProductosPorGenero('Historia')">Historia</a>
        <a href="#" onclick="mostrarProductosPorGenero('Acción')">Acción</a>
        <a href="#" onclick="mostrarProductosPorGenero('Superhéroes')">Superhéroes</a>
        <a href="#" onclick="mostrarProductosPorGenero('Noir')">Noir</a>
        <a href="#" onclick="mostrarProductosPorGenero('Romance')">Romance</a>
        <a href="#" onclick="mostrarProductosPorGenero('Misterio')">Misterio</a>
        <a href="#" onclick="mostrarProductosPorGenero('Suspense')">Suspense</a>
        <a href="#" onclick="mostrarProductosPorGenero('Poesía')">Poesía</a>
    </div>

    <!-- Botón con las tres barras horizontales para abrir la barra lateral -->
    <button class="open-btn" onclick="toggleSidebar()">☰</button>

    <header>
        <a href="index.php " class="logo">
            <img src="rsc/logo.png" alt="Logo">
            <h2>ooks</h2>
        </a>
        <nav>
            <ul>
                <li><a href="libros.php" class="nav-link">Libros</a>
                    <ul>
                        <li><a href="#">Ficción</a></li>
                        <li><a href="#">No Ficción</a></li>
                        <li><a href="#">Biografías</a></li>
                        <li><a href="#">Ciencia Ficción</a></li>
                    </ul>
                </li>
                <li><a href="comics.php" class="nav-link">Comics</a>
                    <ul>
                        <li><a href="#">Superhéroes</a></li>
                        <li><a href="#">Manga</a></li>
                        <li><a href="#">Historietas</a></li>
                    </ul>
                </li>
                <li><a href="audio_libros.php" class="nav-link">Audio Libros</a>
                    <ul>
                        <li><a href="#">Narrativa</a></li>
                        <li><a href="#">Poesía</a></li>
                        <li><a href="#">Entretenimiento</a></li>
                    </ul>
                </li>
                <li><a href="estanteria.php" class="nav-link">Estanterias</a></li>
                <li><a href="biblioteca.php" class="nav-link">Mi Biblioteca</a></li>
                <li><a href="in-sign.php" class="botton-iniciar">Sign In</a></li>
                <li><a href="php_in-sing/cerrar_sesion.php" class="botton-iniciar">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <div id="carouselExampleIndicators" class="carousel">
        <div class="hero-text">
            <h1 class="mb-4">Estantería</h1>
        </div>
    </div>

    <!-- Contenido de la página (por ejemplo, productos, libros, etc.) -->
    <div id="app" class="container">
        <!-- Los productos se cargarán dinámicamente aquí -->
    </div>

    <script>
        // Función para abrir y cerrar la barra lateral
        function toggleSidebar() {
            var sidebar = document.getElementById("mySidebar");
            var content = document.querySelector('.content');
            if (sidebar.style.left === "-250px") {
                sidebar.style.left = "0"; // Mostrar la barra lateral
                content.style.marginLeft = "250px"; // Empujar el contenido
            } else {
                sidebar.style.left = "-250px"; // Ocultar la barra lateral
                content.style.marginLeft = "0"; // Volver al margen original
            }
        }

        // Función para mostrar los productos de un género
        function mostrarProductosPorGenero(genero) {
            // Realizar una solicitud al servidor para obtener los productos del género seleccionado
            fetch(`productos.php?genero=${genero}`)
                .then(response => response.json())
                .then(data => {
                    // Limpiar los productos actuales en la página
                    const container = document.getElementById("app");
                    container.innerHTML = '';

                    // Si hay productos, mostrar en la página
                    if (data.length > 0) {
                        data.forEach(producto => {
                            const productoDiv = document.createElement('div');
                            productoDiv.classList.add('card-wrap');
                            productoDiv.innerHTML = `
                                <div class='card' data-idproducto='${producto.idproducto}'>
                                    <div class='card-inner'>
                                        <div class='card-front'>
                                            <img src='${producto.portada}' alt='${producto.titulo}' class='card-image'>
                                        </div>
                                        <div class='card-back'>
                                            <h1>${producto.titulo}</h1>
                                            <p>${producto.sinopsis}</p>
                                        </div>
                                    </div>
                                </div>
                            `;
                            container.appendChild(productoDiv);
                        });
                    } else {
                        container.innerHTML = '<p>No se encontraron productos para este género.</p>';
                    }
                })
                .catch(error => console.error('Error al cargar los productos:', error));
        }
    </script>

    <footer>
        <div class="footer-container">
            <div class="logo">
                <img src="rsc/logo.png" alt="Logo">
            </div>
            <div class="footer-text">
                <p>Texto del Footer</p>
            </div>
            <div class="logos">
                <img src="rsc/logo1.png" alt="Logo 1">
                <img src="rsc/logo2.png" alt="Logo 2">
            </div>
        </div>
    </footer>
</body>
</html>
