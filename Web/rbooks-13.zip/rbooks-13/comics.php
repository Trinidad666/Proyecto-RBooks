<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RBooks</title>
    <link rel="stylesheet" type="text/css" href="css/comics-style.css" />
    <link rel="stylesheet" type="text/css" href="css/header.css" />
    <link rel="stylesheet" type="text/css" href="css/footer.css" />
    <link rel="icon" type="image/x-icon" href="rsc/logo.png">
    <style>
        .title {
            font-family: "Raleway";
            font-size: 24px;
            font-weight: 700;
            color: #5D4037;
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <header>
        <a href="index.php " class="logo">
            <img src="rsc/logo.png" alt="Logo">
            <h2>ooks</h2>
        </a>
        <nav>
            <ul>
                <li><a href="libros.php" class="nav-link">Libros</a>
                    <ul>
                        <li><a href="#">Ficción</a></li>
                        <li><a href="#">No Ficción</a></li>
                        <li><a href="#">Biografías</a></li>
                        <li><a href="#">Ciencia Ficción</a></li>
                    </ul>
                </li>
                <li><a href="comics.php" class="nav-link">Comics</a>
                    <ul>
                        <li><a href="#">Superhéroes</a></li>
                        <li><a href="#">Manga</a></li>
                        <li><a href="#">Historietas</a></li>
                    </ul>
                </li>
                <li><a href="audio_libros.php" class="nav-link">Audio Libros</a>
                    <ul>
                        <li><a href="#">Narrativa</a></li>
                        <li><a href="#">Educativos</a></li>
                        <li><a href="#">Entretenimiento</a></li>
                    </ul>
                </li>
                <li><a href="estanteria.php" class="nav-link">Estanterías</a></li>
                <li><a href="biblioteca.php" class="nav-link">Mi Biblioteca</a></li>
                <li><a href="in-sign.php" class="botton-iniciar">Sign In</a></li>
                <li><a href="php_in-sing/cerrar_sesion.php" class="botton-iniciar">Cerrar Sesión</a></li>

            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <div id="carouselExampleIndicators" class="carousel">
        
        <div class="hero-text">
            <h1 class="mb-4">Cómics</h1>
        </div>
    </div>

    <!-- //////////////////////////////////////////// -->
    <!-- LibrosS -->
    <!-- //////////////////////////////////////////// -->
    <!-- Hover over the cards
    <h1 class="title">Libros</h1> -->
    <?php 
    include "php_in-sing/conexion_be.php";
    $sql = "SELECT * FROM producto WHERE tipo = 1";
    $result = mysqli_query($conn, $sql);        
    ?>

    <div id="app" class="container">
        <?php 
        if(mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
        
                # <!-- Tarjeta -->
                echo "<div class='card-wrap'>";
                    echo "<div class='card' data-idproducto='" . $row["idproducto"] . "'>";
                        echo "<div class='card-inner'>";
                            echo "<div class='card-front'>";
                                // Imagen del libro
                                echo "<img src='" . $row["portada"] . "' alt='" . $row["titulo"] . "' class='card-image'>";
                            echo "</div>";
                            echo "<div class='card-back'>";
                                // Detalles del libro
                                echo "<h1>" . $row["titulo"] . "</h1>";
                                echo "<p>" . $row["sinopsis"] . "</p>";
                            echo "</div>";
                        echo "</div>";
                    echo "</div>";
                echo "</div>";
        
            }
        }
        ?>
    </div>


    <script>
        // Al hacer clic en cualquier tarjeta, redirigir a la página producto-libros.php
        const cards = document.querySelectorAll('.card-wrap'); // Seleccionar el contenedor de la tarjeta
        cards.forEach(card => {
            card.addEventListener('click', () => {
                const idproducto = card.querySelector('.card').getAttribute('data-idproducto');
                window.location.href = `producto.php?idproducto=${idproducto}`;
            });
        });
    </script>





    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <!-- Logo -->
            <div class="logo">
                <img src="rsc/logo.png" alt="Logo">
            </div>
            <!-- Texto del footer -->
            <div class="footer-text">
                <p>Texto del Footer</p>
            </div>
            <!-- Logotipos -->
            <div class="logos">
                <img src="rsc/Youtube.png" alt="Logo 1">
                <img src="rsc/discord.png" alt="Logo 2">
                <img src="rsc/Instagram-removebg-preview.png" alt="Logo 3">
                <!-- <img src="rsc/Youtube.png" alt="Logo 4"> -->
            </div>
        </div>
    </footer>
</body>
</html>



<!-- para las imagenes:

https://cloudconvert.com/webp-to-jpg -->
