<?php
session_start();
include "php_in-sing/conexion_be.php";

// Inicializamos variables de mensajes
$mensajeExito = "";
$mensajeError = "";

$producto = null;

// Validación del producto a mostrar
if (isset($_GET['idproducto'])) {
    $idproducto = intval($_GET['idproducto']);

    $stmt = $conn->prepare("SELECT * FROM producto WHERE idproducto = ?");
    $stmt->bind_param("i", $idproducto);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $producto = $result->fetch_assoc();
    } else {
        $mensajeError = "Producto no encontrado.";
    }

    $stmt->close();
} else {
    $mensajeError = "No se ha proporcionado un ID de producto.";
}

// Procesar el formulario si se hace clic en "Guardar"
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar que el usuario esté autenticado
    if (isset($_SESSION['idCliente'])) {
        $idCliente = $_SESSION['idCliente'];
        $idProducto = intval($_POST['idproducto']);

        // Verificar suscripción activa
        $querySuscripcion = "SELECT * FROM Suscripciones WHERE idcliente = ? AND estado = 'activa'";
        $stmt = $conn->prepare($querySuscripcion);
        $stmt->bind_param("i", $idCliente);
        $stmt->execute();
        $resultSuscripcion = $stmt->get_result();

        if ($resultSuscripcion->num_rows > 0) {
            // Cliente suscrito: insertar el producto en la biblioteca
            $queryGuardar = "INSERT INTO Mi_Biblioteca (idcliente, idproducto) VALUES (?, ?)";
            $stmtGuardar = $conn->prepare($queryGuardar);
            $stmtGuardar->bind_param("ii", $idCliente, $idProducto);

            if ($stmtGuardar->execute()) {
                $mensajeExito = "Producto agregado a tu biblioteca con éxito.";
            } else {
                $mensajeError = "Error al guardar el producto: " . $stmtGuardar->error;
            }

            $stmtGuardar->close();
        } else {
            $mensajeError = "No puedes agregar productos a la biblioteca. Suscríbete para disfrutar de este servicio.";
        }

        $stmt->close();
    } else {
        $mensajeError = "Por favor, inicia sesión para guardar productos.";
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del Producto</title>
    <link rel="stylesheet" type="text/css" href="css/producto_libros-style.css" />
    <link rel="stylesheet" type="text/css" href="css/header.css" />
    <link rel="stylesheet" type="text/css" href="css/footer-producto.css" />
    <link rel="icon" type="image/x-icon" href="rsc/logo.png">
</head>
<body>
<header>
    <a href="index.php" class="logo">
        <img src="rsc/logo.png" alt="Logo">
        <h2>ooks</h2>
    </a>
    <nav>
            <ul>
                <li><a href="libros.php" class="nav-link">Libros</a>
                    <ul>
                        <li><a href="#">Ficción</a></li>
                        <li><a href="#">No Ficción</a></li>
                        <li><a href="#">Biografías</a></li>
                        <li><a href="#">Ciencia Ficción</a></li>
                    </ul>
                </li>
                <li><a href="comics.php" class="nav-link">Comics</a>
                    <ul>
                        <li><a href="#">Superhéroes</a></li>
                        <li><a href="#">Manga</a></li>
                        <li><a href="#">Historietas</a></li>
                    </ul>
                </li>
                <li><a href="audio_libros.php" class="nav-link">Audio Libros</a>
                    <ul>
                        <li><a href="#">Narrativa</a></li>
                        <li><a href="#">Educativos</a></li>
                        <li><a href="#">Entretenimiento</a></li>
                    </ul>
                </li>
                <li><a href="estanteria.php" class="nav-link">Estanterías</a></li>
                <li><a href="biblioteca.php" class="nav-link">Mi Biblioteca</a></li>
                <li><a href="in-sign.php" class="botton-iniciar">Sign In</a></li>
                <li><a href="php_in-sing/cerrar_sesion.php" class="botton-iniciar">Cerrar Sesión</a></li>

            </ul>
        </nav>
</header>

<div class="producto-info">
    <?php if ($producto): ?>
        <!-- Mensajes -->
        <?php if ($mensajeExito): ?>
            <p class="mensaje-exito"><?php echo htmlspecialchars($mensajeExito); ?></p>
        <?php endif; ?>
        <?php if ($mensajeError): ?>
            <p class="mensaje-error"><?php echo htmlspecialchars($mensajeError); ?></p>
        <?php endif; ?>

        <!-- Imagen a la izquierda -->
        <img src="<?php echo htmlspecialchars($producto['portada']); ?>" alt="<?php echo htmlspecialchars($producto['titulo']); ?>">
        <!-- Información a la derecha -->
        <div class="detalles">
            <h1><?php echo htmlspecialchars($producto['titulo']); ?></h1>
            <p><strong>Género:</strong> <?php echo htmlspecialchars($producto['generos']); ?></p>
            <p><strong>Sinopsis:</strong> <?php echo htmlspecialchars($producto['sinopsis']); ?></p>
            <p class="precio">Precio: $<?php echo number_format($producto['precio'], 2); ?></p>
            <!-- Botón Guardar -->
            <form action="" method="POST">
                <input type="hidden" name="idproducto" value="<?php echo $producto['idproducto']; ?>">
                <button type="submit" class="guardar-btn">Guardar</button>
            </form>
        </div>
        <!-- Botón Salir -->
        <div class="salir-container">
            <button onclick="window.history.back();" class="salir-btn">Salir</button>
        </div>
    <?php elseif (isset($mensajeError)): ?>
        <p class="error"><?php echo htmlspecialchars($mensajeError); ?></p>
    <?php endif; ?>
</div>

<!-- Footer -->
<footer>
    <div class="footer-container">
        <div class="logo">
            <img src="rsc/logo.png" alt="Logo">
        </div>
        <div class="footer-text">
            <p>Texto del Footer</p>
        </div>
        <div class="logos">
            <img src="rsc/Youtube.png" alt="Logo 1">
            <img src="rsc/discord.png" alt="Logo 2">
            <img src="rsc/Instagram-removebg-preview.png" alt="Logo 3">
        </div>
    </div>
</footer>
</body>
</html>
