<?php
session_start();

// Verifica si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    header("Location: in-sign.php");
    exit;
}

require_once('config.php'); // Archivo de configuración para la conexión a la base de datos

// Obtener los datos del cliente
$usuario = $_SESSION['usuario'];
$query = "SELECT idcliente, usuario, email FROM Cliente WHERE usuario = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $usuario);
$stmt->execute();
$result = $stmt->get_result();
$cliente = $result->fetch_assoc();

if (!$cliente) {
    echo "No se encontró el perfil del usuario.";
    exit;
}

// Procesar la actualización del perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nuevo_email = $_POST['email'];
    $nueva_password = $_POST['password'];

    // Actualizar los datos en la base de datos si el usuario proporciona una nueva contraseña o correo
    if (!empty($nuevo_email)) {
        $update_query = "UPDATE Cliente SET email = ? WHERE idcliente = ?";
        $stmt_update = $conn->prepare($update_query);
        $stmt_update->bind_param("si", $nuevo_email, $cliente['idcliente']);
        $stmt_update->execute();
    }

    if (!empty($nueva_password)) {
        $password_hash = password_hash($nueva_password, PASSWORD_DEFAULT);
        $update_query = "UPDATE Cliente SET password = ? WHERE idcliente = ?";
        $stmt_update = $conn->prepare($update_query);
        $stmt_update->bind_param("si", $password_hash, $cliente['idcliente']);
        $stmt_update->execute();
    }

    // Redirigir después de la actualización
    header("Location: profile.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - RBooks</title>
    <link rel="stylesheet" href="css/profile.css">
</head>
<body>
    <header>
        <h2>Mi Perfil</h2>
        <nav>
            <ul>
                <li><a href="index.php">Inicio</a></li>
                <li><a href="logout.php">Cerrar sesión</a></li>
            </ul>
        </nav>
    </header>

    <div class="profile-container">
        <h3>Bienvenido, <?php echo htmlspecialchars($cliente['usuario']); ?></h3>
        
        <div class="profile-info">
            <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($cliente['email']); ?></p>
        </div>

        <div class="profile-edit">
            <h4>Editar Perfil</h4>
            <form action="profile.php" method="POST">
                <label for="email">Nuevo Correo Electrónico:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($cliente['email']); ?>">

                <label for="password">Nueva Contraseña:</label>
                <input type="password" id="password" name="password" placeholder="Introduce una nueva contraseña">

                <button type="submit">Guardar cambios</button>
            </form>
        </div>
    </div>

</body>
</html>

<?php
// Cerrar la conexión a la base de datos
$stmt->close();
$conn->close();
?>
