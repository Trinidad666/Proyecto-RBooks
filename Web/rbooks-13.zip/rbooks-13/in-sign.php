<?php
session_start();

if (isset($_SESSION['usuario'])) {
    header("location: index.php");
}

$mensajeRegistro = ''; // Variable para mensajes en el registro
$mensajeLogin = ''; // Variable para mensajes en el login

// Verificar si se envió el formulario de inicio de sesión
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    require_once('php_in-sing/conexion_be.php'); // Archivo de conexión a la base de datos

    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Consulta para verificar usuario
    $query = $conn->prepare("SELECT * FROM Cliente WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $resultado = $query->get_result();

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();

        // Verificar si la contraseña coincide
        if (password_verify($password, $usuario['password'])) {
            $_SESSION['usuario'] = $usuario['usuario']; // Guardar usuario en la sesión
            header("location: index.php");
            exit();
        } else {
            $mensajeLogin = "La contraseña es incorrecta."; // Contraseña incorrecta
        }
    } else {
        $mensajeLogin = "El correo electrónico no está registrado."; // Usuario no encontrado
    }

    $query->close();
    $conn->close();
}

// Verificar si se envió el formulario de registro
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    require_once('php_in-sing/conexion_be.php'); // Archivo de conexión a la base de datos

    $email = trim($_POST['email']);
    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['password']);

    // Verificar si el correo o usuario ya existen
    $query = $conn->prepare("SELECT * FROM Cliente WHERE email = ? OR usuario = ?");
    $query->bind_param("ss", $email, $usuario);
    $query->execute();
    $resultado = $query->get_result();

    if ($resultado->num_rows > 0) {
        $mensajeRegistro = "El correo o el usuario ya están registrados.";
    } else {
        // Si no existen, proceder con el registro
        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        $query = $conn->prepare("INSERT INTO Cliente (email, usuario, password) VALUES (?, ?, ?)");
        $query->bind_param("sss", $email, $usuario, $password_hash);

        if ($query->execute()) {
            $mensajeRegistro = "Registro exitoso. Por favor, inicia sesión.";
        } else {
            $mensajeRegistro = "Hubo un error al registrarte. Inténtalo de nuevo.";
        }
    }

    $query->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login y Registro</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assents/css/estilos.css?v=1.0">
    <link rel="icon" type="image/x-icon" href="rsc/logo.png">
    <style>
        .mensaje {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
            text-align: center;
        }
        .mensaje.error {
            background-color: #f8d7da;
            color: #842029;
        }
        .mensaje.success {
            background-color: #d1e7dd;
            color: #0f5132;
        }
    </style>
</head>

<body>
    <main>
        <div class="contendor__todo">
            <div class="caja__trasera">
                <div class="caja__trasera-login">
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para acceder</p>
                    <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                </div>
                <div class="caja__trasera-register">
                    <h3>¿Aún No Tienes una Cuenta?</h3>
                    <p>Regístrate para Acceder</p>
                    <!-- Eliminamos la acción de cambiar de vista -->
                    <button id="btn__registrarse">Registrarme</button>
                </div>
            </div>

            <!-- Formulario de login y Registro -->
            <div class="contenedor__login-register">
                <!-- Login -->
                <form action="" method="POST" class="formulario__login">
                    <h2>Iniciar Sesión</h2>

                    <!-- Mostrar mensaje de error si lo hay -->
                    <?php if (!empty($mensajeLogin)): ?>
                        <div class="mensaje error"><?php echo htmlspecialchars($mensajeLogin); ?></div>
                    <?php endif; ?>

                    <input type="text" placeholder="Email" name="email" required>
                    <input type="password" placeholder="Password" name="password" required>
                    <button name="login">Acceder</button>
                    <br>
                    <br>
                    <a href="php_in-sing/olvide-password.php" class="cambiar_password.php">¿Olvidaste tu Contraseña?</a>
                </form>

                <!-- Registro -->
                <form action="" method="POST" class="formulario__register">
                    <h2>Registrarme</h2>

                    <!-- Mostrar mensaje de registro si lo hay -->
                    <?php if (!empty($mensajeRegistro)): ?>
                        <div class="mensaje <?php echo strpos($mensajeRegistro, 'exitoso') !== false ? 'success' : 'error'; ?>">
                            <?php echo htmlspecialchars($mensajeRegistro); ?>
                        </div>
                    <?php endif; ?>

                    <input type="text" placeholder="Email" name="email" required>
                    <input type="text" placeholder="Usuario" name="usuario" required>
                    <input type="password" placeholder="Password" name="password" required>
                    <button name="register">Registrarme</button>
                </form>
            </div>
        </div>
    </main>

    <script src="assents/js/script.js"></script>
</body>

</html>
