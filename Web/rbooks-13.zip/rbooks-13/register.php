<?php
// Iniciar la sesión
session_start();
include("conexion.php");  // Asegúrate de tener el archivo de conexión adecuado

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $usuario = $_POST['usuario'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Encriptamos la contraseña

    // Verificar si el usuario ya existe
    $sql = "SELECT * FROM Cliente WHERE usuario = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $usuario, $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "El usuario o el correo electrónico ya están registrados.";
    } else {
        // Si no existe, insertar el nuevo usuario
        $insert_sql = "INSERT INTO Cliente (usuario, email, password) VALUES (?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("sss", $usuario, $email, $password);
        if ($insert_stmt->execute()) {
            echo "¡Registro exitoso!";
            header("Location: in-sign.php");  // Redirigir a la página de inicio de sesión
            exit();
        } else {
            echo "Error en el registro. Inténtalo de nuevo.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - RBooks</title>
    <link rel="stylesheet" href="assents/css/estilos.css?v=1.0">
    <link rel="icon" type="image/x-icon" href="rsc/logo.png">
</head>
<body>
    <main>
        <div class="contendor__todo">
            <div class="contenedor__login-register">
                <!-- Formulario de Registro -->
                <form action="register.php" method="POST" class="formulario__register">
                    <h2>Registrarme</h2>
                    <input type="text" placeholder="Usuario" name="usuario" required>
                    <input type="text" placeholder="Email" name="email" required>
                    <input type="password" placeholder="Password" name="password" required>
                    <button>Registrarme</button>
                    <p>¿Ya tienes cuenta? <a href="in-sign.php">Inicia sesión aquí</a></p>
                </form>
            </div>
        </div>
    </main>
</body>
</html>
