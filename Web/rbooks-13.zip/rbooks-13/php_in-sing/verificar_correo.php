<?php
// Configuración de la conexión a la base de datos
$host = 'localhost'; // O el nombre del servidor de tu base de datos
$dbname = 'rbooks'; // Reemplázalo con el nombre de tu base de datos
$username = 'root'; // Tu nombre de usuario de la base de datos
$password = ''; // Tu contraseña de la base de datos

// Crear la conexión
$conn = new mysqli($host, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
};

// Obtener los correos enviados por el formulario
$emails = $_POST['emails']; // Los correos deben estar separados por comas

// Convertir los correos a un arreglo
$emailArray = explode(',', $emails);

// Eliminar espacios en blanco de cada correo
$emailArray = array_map('trim', $emailArray);

// Inicializar un array para los correos no encontrados
$noEncontrados = [];

// Verificar cada correo en la base de datos
foreach ($emailArray as $email) {
    // Preparar la consulta SQL para verificar si el correo existe en la base de datos
    $sql = "SELECT * FROM Cliente WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Comprobar si el correo está registrado
    if ($result->num_rows > 0) {
        echo "El correo '$email' está registrado.<br>";
    } else {
        // Si no está registrado, agregarlo a la lista de no encontrados
        $noEncontrados[] = $email;
    }
}

// Mostrar los correos no encontrados
if (!empty($noEncontrados)) {
    echo "<br><strong>Correos no encontrados:</strong><br>";
    foreach ($noEncontrados as $noEncontrado) {
        echo "$noEncontrado<br>";
    }
}

// Cerrar la conexión
$conn->close();
?>
