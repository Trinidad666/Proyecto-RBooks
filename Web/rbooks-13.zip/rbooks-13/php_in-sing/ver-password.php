<?php
// Incluye tu archivo de conexión
include('conexion_be.php');

// Verifica si se envió el formulario
if (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Crea la consulta preparada para evitar inyección SQL
    $query = $conn->prepare("SELECT password FROM Cliente WHERE email = ?");
    $query->bind_param("s", $email);

    // Ejecuta la consulta
    $query->execute();
    $result = $query->get_result();

    // Verifica si se encontró el correo
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo "La contraseña para el correo {$email} es: " . htmlspecialchars($row['password']);
    } else {
        echo "No se encontró un cliente con ese correo electrónico.";
    }

    // Cierra la consulta y conexión
    $query->close();
    $conn->close();
} else {
    echo "Por favor, ingresa un correo electrónico.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
</head>
<body>
    <form method="POST" action="">
        <label for="email">Correo Electrónico:</label>
        <input type="email" name="email" id="email" required>
        <button type="submit">Recuperar Contraseña</button>
    </form>
</body>
</html>
