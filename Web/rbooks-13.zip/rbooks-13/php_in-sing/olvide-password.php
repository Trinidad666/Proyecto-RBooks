<?php
// Configuración de la conexión a la base de datos
$host = 'localhost';
$dbname = 'rbooks';
$username = 'root';
$password = '';

// Crear la conexión
$conn = new mysqli($host, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Variables para mensajes
$mensaje = '';
$clase = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar si el campo 'email' está presente en $_POST
    if (isset($_POST['email'])) {
        $email = $_POST['email']; // Correos separados por comas
        $emailArray = array_map('trim', explode(',', $email)); // Separar y limpiar correos
        $noEncontrados = []; // Almacenar correos no registrados

        foreach ($emailArray as $email) {
            // Validar formato del correo electrónico
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $mensaje = "Formato de correo no válido: $email";
                $clase = 'error'; // Clase para fondo rojo
                break;
            }

            // Verificar si el correo existe en la base de datos
            $query = $conn->prepare("SELECT * FROM Cliente WHERE email = ?");
            $query->bind_param("s", $email);
            $query->execute();
            $resultado = $query->get_result();

            if ($resultado->num_rows > 0) {
                // Enviar correo si está registrado
                include('enviar_correo.php');
                $mensaje = "El mensaje ha sido enviado a $email.";
                $clase = 'exito'; // Clase para fondo verde
            } else {
                $noEncontrados[] = $email; // Agregar a la lista de no encontrados
            }
        }

        if (!empty($noEncontrados)) {
            $mensaje = "Los siguientes correos no están registrados: " . implode(', ', $noEncontrados);
            $clase = 'advertencia'; // Clase para fondo amarillo
        }

        $query->close();
    } else {
        $mensaje = "Por favor, completa el campo de correo.";
        $clase = 'error'; // Clase para fondo rojo
    }
}

// Cerrar la conexión
$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Recuperación de Contraseña</title>
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/style.css">
        <link rel="icon" type="image/x-icon" href="../rsc/logo.png">
        <style>
            button {
            padding: 10px;
            background-color: #FF5722;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            }
            button:hover {
                background-color: #E64A19;
            }
            .mensaje {
                margin-bottom: 15px;
                padding: 10px;
                border-radius: 5px;
                font-size: 14px;
            }
            .mensaje.error {
                background-color: #f8d7da;
                color: #842029;
            }
            .mensaje.exito {
                background-color: #d1e7dd;
                color: #0f5132;
            }
            .mensaje.advertencia {
                background-color: #fff3cd;
                color: #664d03;
            }

        </style>
    </head>
    <body>
        <main>
            <div class="contendor__todo">
                <div class="caja__trasera">
                    <div>
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                        <h2>Recuperación de Contraseña</h2>

                        <!-- Mostrar mensaje dinámico -->
                        <?php if (!empty($mensaje)): ?>
                            <div class="mensaje <?php echo $clase; ?>">
                                <?php echo $mensaje; ?>
                            </div>
                        <?php endif; ?>
                        
                        <input type="text" placeholder="Email" name="email" required>
                        <button type="submit">Enviar Correo</button>
                    </form>
                    </div>
                </div>
            </div>
        </main>
    </body>
</html>
