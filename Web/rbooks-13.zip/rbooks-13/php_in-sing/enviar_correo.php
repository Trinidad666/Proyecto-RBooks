<?php
// Incluir la librería PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\smtp;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';  // Asegúrate de que el autoload de Composer esté disponible

// Verifica si el formulario fue enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener el correo electrónico del formulario
    $destinatario = $_POST['email'];

    // Crear una nueva instancia de PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Configuración del servidor SMTP de Gmail
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Servidor SMTP de Gmail
        $mail->SMTPAuth = true;
        $mail->Username = 'rbooksrbooks23@gmail.com';  // Tu correo de Gmail
        $mail->Password = 'rurragiyswjytkny';  // Aquí va la contraseña de aplicación generada
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  // Usar TLS para seguridad
        $mail->Port = 587;  // Puerto SMTP de Gmail

        // Remitente y destinatarios
        $mail->setFrom('rbooksrbooks23@gmail.com', 'Rbooks');  // Tu correo y nombre
        $mail->addAddress($destinatario);  // Dirección de correo del destinatario (la que el usuario ingrese)

        // Contenido del correo
        $mail->isHTML(true);  // El correo será enviado en formato HTML
        $mail->Subject = 'Asunto del correo';  // Asunto del correo
        $mail->Body    = 'Este es el <b>contenido del mensaje en HTML</b>. <br><br> http://localhost/rbooks/php_in-sing/cambiar_password.php';  // Cuerpo del mensaje en HTML
        // $mail->AltBody = 'Este es el contenido en texto plano para clientes que no soportan HTML.';  // Cuerpo en texto plano

        // Enviar el correo
        if ($mail->send()) {
            echo'';
        } else {
            echo'';
        }
    } catch (Exception $e) {
        echo "No se pudo enviar el mensaje. Error de Mailer: {$mail->ErrorInfo}";
    }
} else {
    echo "Por favor, llena el formulario.";
}
?>
