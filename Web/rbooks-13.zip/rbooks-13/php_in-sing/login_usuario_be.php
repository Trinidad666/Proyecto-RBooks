<?php
session_start();
include 'conexion_be.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM Cliente WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Almacenar tanto el nombre de usuario como el idCliente en la sesión
            $_SESSION['usuario'] = $row['usuario'];
            $_SESSION['idCliente'] = $row['idCliente'];  // Aquí estamos almacenando el idCliente
            header("Location: ../index.php");
        } else {
            echo "Password incorrecto.";
        }
    } else {
        echo "No se encontró un usuario con ese email.";
    }
    $conn->close();
}
?>
