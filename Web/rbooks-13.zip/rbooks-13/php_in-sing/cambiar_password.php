<?php
// Incluir archivo de conexión
require_once('conexion_be.php');

// Variables para mensajes
$mensaje = '';
$clase = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener datos del formulario
    $email = trim($_POST['email']);
    $nueva_password = trim($_POST['nueva_contraseña']);
    $nueva_password_confirmar = trim($_POST['nueva_contraseña_confirmar']);
    
    // Validar que las contraseñas coincidan
    if ($nueva_password !== $nueva_password_confirmar) {
        $mensaje = "Las contraseñas no coinciden.";
        $clase = 'error'; // Clase para fondo rojo
    } else {
        // Validar formato de correo electrónico
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $mensaje = "El correo electrónico no es válido.";
            $clase = 'error'; // Clase para fondo rojo
        } else {
            // Encriptar la nueva contraseña
            $nueva_password_hashed = password_hash($nueva_password, PASSWORD_DEFAULT);
            
            // Buscar usuario por correo electrónico
            $query = $conn->prepare("SELECT * FROM Cliente WHERE email = ?");
            $query->bind_param("s", $email);
            $query->execute();
            $resultado = $query->get_result();
            
            // Verificar si el correo está registrado
            if ($resultado->num_rows > 0) {
                // Actualizar la contraseña
                $query_actualizar = $conn->prepare("UPDATE Cliente SET password = ? WHERE email = ?");
                $query_actualizar->bind_param("ss", $nueva_password_hashed, $email);
                
                if ($query_actualizar->execute()) {
                    $mensaje = "Contraseña actualizada con éxito.";
                    $clase = 'exito'; // Clase para fondo verde
                } else {
                    $mensaje = "Error al actualizar la contraseña.";
                    $clase = 'error'; // Clase para fondo rojo
                }
            } else {
                $mensaje = "El correo no está registrado.";
                $clase = 'advertencia'; // Clase para fondo amarillo
            }
            
            // Cerrar conexiones
            $query->close();
        }
    }
    
    // Cerrar conexión
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" type="image/x-icon" href="../rsc/logo.png">

    
    <style>
        button {
            padding: 10px;
            background-color: #FF5722;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #E64A19;
        }
        .mensaje {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
        }
        .mensaje.error {
            background-color: #f8d7da;
            color: #842029;
        }
        .mensaje.exito {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        .mensaje.advertencia {
            background-color: #fff3cd;
            color: #664d03;
        }
    </style>
</head>
<body>





    <main>
        <div class="contendor__todo">
            <div class="caja__trasera">
                <div>
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                    <h2>Cambiar Contraseña</h2>

                    <!-- Mostrar mensaje dinámico -->
                    <?php if (!empty($mensaje)): ?>
                        <div class="mensaje <?php echo $clase; ?>">
                            <?php echo $mensaje; ?>
                        </div>
                    <?php endif; ?>
                    
                    <input type="email" placeholder="Email" name="email" required>
                    <input type="password" placeholder="Nueva Contraseña" name="nueva_contraseña" required>
                    <input type="password" placeholder="Confirmar Contraseña" name="nueva_contraseña_confirmar" required>
                    <button type="submit">Actualizar Contraseña</button>
                </form>
                </div>
            </div>
        </div>
    </main>

</body>
</html>
